| Model   | Scenario   |   Accuracy |   Throughput | Latency (in ms)   | Power Efficiency (in samples/J)   | TEST01   |
|---------|------------|------------|--------------|-------------------|-----------------------------------|----------|
| rgat    | offline    |     72.813 |      316.253 | -                 |                                   | passed   |